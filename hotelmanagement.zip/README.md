# Step 1 - created a repo on github "project_sql_hotelmgmt" and add README , gitignore, LICENSE then I cloned the repo using vs code

# Step 1a - download world.sql
#         - type in terminal or in the command prompt below command
#         - psql -U postgres -d world -f C:/download/world.sql  

# If error like psql command not found then
# Paste below path in environment variable PATH
# To find Environment variable search in Windows Search bar -> environment variables
# 
# C:\Program Files\PostgreSQL\16\bin

# Step 2 - postgresql, pgadmin 4, docker desktop

# Step 3 - create virtualenv
#        - python -m venv myenv
#        - myenv/Scripts/activate
# 
# Second method to be used if command not found
# Ctrl + shift + p then create environement then venv
# .venv/Scripts/activate

# pip install streamlit, pandas, psycopg2, pipreqs
# pipreqs  - for creating requirements.txt
# psycopg2 - connector for postgresql



