import logging
logging.basicConfig(filename='app.log')

logging.info('starting to import packages')

import streamlit as st #streamlit for website in python

#modules
#from folder_name.file_name import function_name
from services.connect import connect_database #database connection

from services.create_tables import create_hotel_data_tables #Create table

from services.insert import insert_guest, insert_room #Insert data into table

from services.insert_dummy_data import insert_dummy_data #dummy data insert

logging.info('end of import packages')

conn = connect_database() #call function to connect to database

if conn is None: #if connection to db failed
    logging.info('Database connection failed')
    st.write('database connection failed') #print message

else:
    # create data
    logging.info('Creating tables')
    st.subheader("Create tables")
    if st.button("Add tables"):
        logging.info('button clicked')
        #DDL - data definition language (CREATE, ALTER, TRUNCATE,RENAME,DROP)
        #DML - data manipulation language (SELECT,INSERT, UPDATE, DELETE, FROM,WHERE,GROUP BY, JOIN, HAVING, ORDER BY)
        create_hotel_data_tables(conn) #call function
        insert_dummy_data(conn) #data insert
        st.success("Tables added successfully!")

    
    st.title("Hotel Management System")

    # Insert data into rooms table
    st.subheader("Insert Room")
    #selectbox() - dropdown 
    room_type = st.selectbox("Room Type", ["Single", "Double"])
    #number_input() - text box to add a number
    rate = st.number_input("Rate")
    if st.button("Add Room"):
        insert_room(conn, room_type, rate)
        st.success("Room added successfully!")

    # Insert data into guests table
    st.subheader("Insert Guest")
    name = st.text_input("Name")
    email = st.text_input("Email")
    phone_number = st.text_input("Phone Number")
    if st.button("Add Guest"):
        insert_guest(conn, name, email, phone_number)
        st.success("Guest added successfully!")

    # Close the database connection
    conn.close()








