import psycopg2 #connection to postgresql
import traceback #error and debug
def connect_database(): # Function to connect to PostgreSQL
    try:
        #create object of connect()
        conn = psycopg2.connect(
            dbname="suppliers",
            user="postgres",
            password="postgres",
            host="localhost",  # or your PostgreSQL host
            port="5432"        # or your PostgreSQL port
        )
        print("Connected to the database successfully")
        return conn
    except psycopg2.Error as e:
        print(f"Unable to connect to the database: {e}")
        print(traceback.format_exc())
        return None