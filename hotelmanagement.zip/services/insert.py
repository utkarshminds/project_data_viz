# Function to insert data into rooms table
import traceback #error and debug
import logging #logs
import psycopg2  #database connections

def insert_room(conn, room_type, rate):
    '''
    conn: database connection object
    room_type: string
    rate: integer
    '''
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO rooms (room_type, rate) VALUES (%s, %s)
        """, (room_type, rate))
        conn.commit()
        cursor.close()
    except psycopg2.Error as e:
        print(f"Unable to create tables to the database: {e}")
        print(traceback.format_exc())
        logging.info(f"Unable to create tables to the database: {e}")
        logging.info(traceback.format_exc())
        return None

# Function to insert data into guests table
def insert_guest(conn, name, email, phone_number):
    '''
    conn: database connection object
    room_type: string
    rate: integer
    '''
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO guests (name, email, phone_number) VALUES (%s, %s, %s)
        """, (name, email, phone_number))
        conn.commit()
        cursor.close()
    except psycopg2.Error as e:
        print(f"Unable to create tables to the database: {e}")
        print(traceback.format_exc())
        logging.info(f"Unable to create tables to the database: {e}")
        logging.info(traceback.format_exc())
        return None