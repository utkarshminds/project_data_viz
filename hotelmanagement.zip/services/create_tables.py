import psycopg2 #python library to connect to postgres db
import traceback
import logging
# Function to create tables
def create_hotel_data_tables(conn):
    """
    conn: object of psycopg2 connect()
    """

    try:
        cursor = conn.cursor()

        # Create rooms table
        # Three columns
        # room_number - primary key
        # room type - characters/strings
        # rate - integers
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS rooms (
                room_number SERIAL PRIMARY KEY,
                room_type VARCHAR(50),
                rate DECIMAL
            )
        """)

        # Create guests table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS guests (
                guest_id SERIAL PRIMARY KEY,
                name VARCHAR(100),
                email VARCHAR(100),
                phone_number VARCHAR(15)
            )
        """)

        # Create reservations table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS reservations (
                reservation_id SERIAL PRIMARY KEY,
                room_number INTEGER REFERENCES rooms(room_number),
                guest_id INTEGER REFERENCES guests(guest_id),
                check_in DATE,
                check_out DATE,
                FOREIGN KEY (room_number) REFERENCES rooms(room_number),
                FOREIGN KEY (guest_id) REFERENCES guests(guest_id)
            )
        """)

        conn.commit()  #commit-to reflect tables in database
        cursor.close() #cursor closed 
    
    except psycopg2.Error as e:
        print(f"Unable to create tables to the database: {e}")
        print(traceback.format_exc())
        logging.info(f"Unable to create tables to the database: {e}")
        logging.info(traceback.format_exc())
        return None