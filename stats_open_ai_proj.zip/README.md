# day2_python
ChatGPT integration for data science
