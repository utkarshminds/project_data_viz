'''
create a streamlit website 
allow user to enter size 
of house in text box
after user clicks button named 
predict
and using the machine learning 
model stored in pickle format in
the file 
linear_regression_house_price_prediction.pkl 
make the prediction and display on website
'''

import streamlit as st
import pickle
import numpy as np

# Load the model
with open('linear_regression_house_price_prediction.pkl', 'rb') as file:
    model = pickle.load(file)

# Title of the app
st.title('House Price Prediction App')

# Input: Enter the size of the house
house_size = st.text_input('Enter the size of the house (in square feet):')

# Predict button
if st.button('Predict'):
    if house_size:  # Check if input is not empty
        try:
            # Convert input to float
            house_size = float(house_size)
            
            # Make prediction
            prediction = model.predict(np.array([[house_size]]))[0]
            
            # Display the result
            st.success(f"The estimated price for a house of {house_size} sq. ft. is ${prediction:,.2f}.")
        
        except ValueError:
            st.error("Please enter a valid number for the house size.")
    else:
        st.error("Please enter the size of the house.")
