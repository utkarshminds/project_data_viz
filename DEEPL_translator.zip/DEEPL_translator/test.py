import deepl

auth_key = ""  # Replace with your key
translator = deepl.Translator(auth_key)

result = translator.translate_text("Garden", source_lang='EN', target_lang="FR")
print(result.text)  