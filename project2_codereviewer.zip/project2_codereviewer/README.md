# Step 1 - Create a github repo - give the name CodeReview

# Step 2 - Clone the repo on VS Code 

# Step 3 - Create a virtual env 
#      3a Type in terminal - python -m venv myenv 
#      3b                  - myenv/Scripts/activate
# OR
#      3a Type in terminal - Ctrl+Shift+P then Create env
#      3b                  - .venv/Scripts/activate
#                       - python.exe -m pip install --upgrade pip
#      3c                  - pip install openai
#      3d                  - pip install streamlit

# Step 4  - Create a main.py file
#      4a - Create a folder services/
#      4b - Inside services/ create a file call_openai.py
#      4c - create a folder .streamlit/
#      4d - create a file inside .streamlit/ named secrets.toml

# Step 5 - create open ai secret key and copy paste in secrets.toml from platform.openai.com -> dashboard -> create secret key

# Step 6 - go to website https://docs.streamlit.io/knowledge-base/deploy/authentication-without-sso

#   6a - search for option 2 copy the step 1 in secrets.toml
#   6b - search for option 2 step 3 and copy paste the entire code except last two lines in main.py
