# Function to insert dummy data into the students table
import streamlit as st
def insert_dummy_data(conn, cursor):
    try:
        cursor.execute("""
            INSERT INTO students (name, rollno, date, subject)
            VALUES 
                ('John Doe', '123', '2024-03-08', 'Math'),
                ('Jane Smith', '456', '2024-03-08', 'Science'),
                ('Alice Johnson', '789', '2024-03-08', 'English')
        """)
        conn.commit()
        st.success("Dummy data inserted successfully!")
    except Exception as e:
        st.error(f"Error inserting dummy data: {e}")