# Function to display students present on a particular date for a subject
import streamlit as st

def display_attendance(date, subject,conn, cursor):
    try:
        cursor.execute("""
            SELECT name, rollno
            FROM students
            WHERE date = %s AND subject = %s
        """, (date, subject))
        rows = cursor.fetchall()
        if rows:
            st.write("Students present on", date, "for subject", subject)
            for row in rows:
                st.write(row[0], "-", row[1])
        else:
            st.write("No students present on", date, "for subject", subject)
    except Exception as e:
        st.error(f"Error displaying attendance: {e}")