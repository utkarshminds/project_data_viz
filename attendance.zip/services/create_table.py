# Function to create the students table
import streamlit as st
def create_table(conn, cursor):
    try:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id SERIAL PRIMARY KEY,
                name VARCHAR(100),
                rollno VARCHAR(20),
                date DATE,
                subject VARCHAR(100)
            )
        """)
        conn.commit()
        st.success("Students table created successfully!")
    except Exception as e:
        st.error(f"Error creating table: {e}")