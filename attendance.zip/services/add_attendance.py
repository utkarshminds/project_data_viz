# Function to add attendance data into the students table
import streamlit as st

def add_attendance(name, rollno, date, subject,conn, cursor):
    try:
        cursor.execute("""
            INSERT INTO students (name, rollno, date, subject)
            VALUES (%s, %s, %s, %s)
        """, (name, rollno, date, subject))
        conn.commit()
        st.success("Attendance added successfully!")
    except Exception as e:
        st.error(f"Error adding attendance: {e}")